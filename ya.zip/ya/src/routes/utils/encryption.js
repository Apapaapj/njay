// ================================================================
// ENCRYPTION UTILITY
// AES-256 + RSA key exchange for secure communication
// ================================================================

const crypto = require('crypto');

class Encryption {
    constructor() {
        this.algorithm = 'aes-256-gcm';
        this.keyLength = 32;
        this.ivLength = 16;
        this.tagLength = 16;
    }

    // ============================================================
    // AES-256-GCM
    // ============================================================

    encrypt(text, key) {
        const iv = crypto.randomBytes(this.ivLength);
        const cipher = crypto.createCipheriv(this.algorithm, this.getKey(key), iv);
        let encrypted = cipher.update(text, 'utf8', 'hex');
        encrypted += cipher.final('hex');
        const tag = cipher.getAuthTag();
        return {
            iv: iv.toString('hex'),
            encrypted: encrypted,
            tag: tag.toString('hex')
        };
    }

    decrypt(encryptedData, key) {
        const iv = Buffer.from(encryptedData.iv, 'hex');
        const tag = Buffer.from(encryptedData.tag, 'hex');
        const decipher = crypto.createDecipheriv(this.algorithm, this.getKey(key), iv);
        decipher.setAuthTag(tag);
        let decrypted = decipher.update(encryptedData.encrypted, 'hex', 'utf8');
        decrypted += decipher.final('utf8');
        return decrypted;
    }

    getKey(key) {
        return crypto.createHash('sha256').update(key).digest();
    }

    // ============================================================
    // RSA
    // ============================================================

    generateRSAKeys() {
        return crypto.generateKeyPairSync('rsa', {
            modulusLength: 2048,
            publicKeyEncoding: {
                type: 'spki',
                format: 'pem'
            },
            privateKeyEncoding: {
                type: 'pkcs8',
                format: 'pem'
            }
        });
    }

    encryptRSA(text, publicKey) {
        const buffer = Buffer.from(text, 'utf8');
        const encrypted = crypto.publicEncrypt(publicKey, buffer);
        return encrypted.toString('base64');
    }

    decryptRSA(text, privateKey) {
        const buffer = Buffer.from(text, 'base64');
        const decrypted = crypto.privateDecrypt(privateKey, buffer);
        return decrypted.toString('utf8');
    }

    // ============================================================
    // HASHING
    // ============================================================

    hash(text, algorithm = 'sha256') {
        return crypto.createHash(algorithm).update(text).digest('hex');
    }

    hashWithSalt(text, salt) {
        return crypto.createHash('sha256').update(text + salt).digest('hex');
    }

    generateSalt(length = 16) {
        return crypto.randomBytes(length).toString('hex');
    }

    // ============================================================
    // TOKEN
    // ============================================================

    generateToken(length = 32) {
        return crypto.randomBytes(length).toString('hex');
    }

    verifyToken(token, secret) {
        const expected = this.hash(token, secret);
        return expected === token;
    }

    // ============================================================
    // DATA MASKING
    // ============================================================

    maskData(text, visible = 4) {
        if (!text) return '';
        if (text.length <= visible * 2) return text;
        const first = text.substring(0, visible);
        const last = text.substring(text.length - visible);
        return first + '*'.repeat(Math.min(text.length - visible * 2, 20)) + last;
    }

    maskEmail(email) {
        if (!email) return '';
        const parts = email.split('@');
        if (parts.length !== 2) return this.maskData(email, 3);
        return this.maskData(parts[0], 2) + '@' + parts[1];
    }

    maskPhone(phone) {
        if (!phone) return '';
        if (phone.length < 8) return phone;
        return phone.substring(0, 4) + '****' + phone.substring(phone.length - 3);
    }
}

module.exports = new Encryption();