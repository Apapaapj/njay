// ================================================================
// LOGGER UTILITY
// Structured logging with colors and levels
// ================================================================

const fs = require('fs');
const path = require('path');

class Logger {
    constructor() {
        this.levels = {
            debug: 0,
            info: 1,
            success: 2,
            warning: 3,
            error: 4,
            fatal: 5
        };

        this.levelColors = {
            debug: '\x1b[36m',   // cyan
            info: '\x1b[34m',    // blue
            success: '\x1b[32m', // green
            warning: '\x1b[33m', // yellow
            error: '\x1b[31m',   // red
            fatal: '\x1b[35m'    // magenta
        };

        this.resetColor = '\x1b[0m';
        this.minLevel = 'info';
        this.logFile = path.join(__dirname, '../../logs/app.log');
        this.consoleEnabled = true;
        this.fileEnabled = true;

        // Create logs directory if not exists
        const logDir = path.dirname(this.logFile);
        if (!fs.existsSync(logDir)) {
            fs.mkdirSync(logDir, { recursive: true });
        }
    }

    // ============================================================
    // LOG METHODS
    // ============================================================

    debug(message, meta = {}) {
        this.log('debug', message, meta);
    }

    info(message, meta = {}) {
        this.log('info', message, meta);
    }

    success(message, meta = {}) {
        this.log('success', message, meta);
    }

    warning(message, meta = {}) {
        this.log('warning', message, meta);
    }

    error(message, meta = {}) {
        this.log('error', message, meta);
    }

    fatal(message, meta = {}) {
        this.log('fatal', message, meta);
    }

    // ============================================================
    // CORE LOG METHOD
    // ============================================================

    log(level, message, meta = {}) {
        const levelValue = this.levels[level] || 0;
        const minLevelValue = this.levels[this.minLevel] || 0;

        if (levelValue < minLevelValue) {
            return;
        }

        const timestamp = new Date().toISOString();
        const logEntry = {
            timestamp: timestamp,
            level: level.toUpperCase(),
            message: message,
            meta: meta,
            pid: process.pid
        };

        // Console output
        if (this.consoleEnabled) {
            this.printToConsole(level, logEntry);
        }

        // File output
        if (this.fileEnabled) {
            this.writeToFile(logEntry);
        }
    }

    // ============================================================
    // CONSOLE OUTPUT
    // ============================================================

    printToConsole(level, logEntry) {
        const color = this.levelColors[level] || '';
        const levelStr = logEntry.level.padEnd(7);
        const metaStr = Object.keys(logEntry.meta).length > 0 ?
            ' ' + JSON.stringify(logEntry.meta) : '';

        console.log(
            `${color}[${logEntry.timestamp}] ${levelStr} ${logEntry.message}${metaStr}${this.resetColor}`
        );
    }

    // ============================================================
    // FILE OUTPUT
    // ============================================================

    writeToFile(logEntry) {
        try {
            const line = JSON.stringify(logEntry) + '\n';
            fs.appendFileSync(this.logFile, line);
        } catch (err) {
            // Silent fail untuk file logging
        }
    }

    // ============================================================
    // SPECIAL LOGGERS
    // ============================================================

    clientConnected(clientId, clientName) {
        this.success(`Client connected: ${clientName} (${clientId})`, {
            clientId: clientId,
            clientName: clientName,
            type: 'connection'
        });
    }

    clientDisconnected(clientId, clientName) {
        this.warning(`Client disconnected: ${clientName} (${clientId})`, {
            clientId: clientId,
            clientName: clientName,
            type: 'disconnection'
        });
    }

    commandSent(clientId, command) {
        this.info(`Command sent to ${clientId}: ${command}`, {
            clientId: clientId,
            command: command,
            type: 'command'
        });
    }

    commandResult(clientId, command, result) {
        this.debug(`Command result from ${clientId}: ${command}`, {
            clientId: clientId,
            command: command,
            resultLength: result ? result.length : 0,
            type: 'result'
        });
    }

    serverStart(port) {
        this.success(`Server started on port ${port}`, {
            port: port,
            type: 'server'
        });
    }

    serverError(error) {
        this.fatal(`Server error: ${error.message}`, {
            error: error.message,
            stack: error.stack,
            type: 'server'
        });
    }

    // ============================================================
    // UTILITY
    // ============================================================

    setMinLevel(level) {
        if (this.levels[level] !== undefined) {
            this.minLevel = level;
        }
    }

    enableConsole() {
        this.consoleEnabled = true;
    }

    disableConsole() {
        this.consoleEnabled = false;
    }

    enableFile() {
        this.fileEnabled = true;
    }

    disableFile() {
        this.fileEnabled = false;
    }

    setLogFile(path) {
        this.logFile = path;
        const dir = path.dirname(path);
        if (!fs.existsSync(dir)) {
            fs.mkdirSync(dir, { recursive: true });
        }
    }

    getLogs(limit = 100) {
        try {
            if (!fs.existsSync(this.logFile)) {
                return [];
            }
            const content = fs.readFileSync(this.logFile, 'utf8');
            const lines = content.split('\n').filter(line => line.trim());
            const logs = lines.map(line => {
                try {
                    return JSON.parse(line);
                } catch {
                    return null;
                }
            }).filter(log => log !== null);
            return logs.slice(-limit);
        } catch (err) {
            return [];
        }
    }

    clearLogs() {
        try {
            if (fs.existsSync(this.logFile)) {
                fs.writeFileSync(this.logFile, '');
            }
        } catch (err) {
            // Silent fail
        }
    }

    // ============================================================
    // FORMATTER
    // ============================================================

    formatDuration(ms) {
        const seconds = Math.floor(ms / 1000);
        const minutes = Math.floor(seconds / 60);
        const hours = Math.floor(minutes / 60);
        const days = Math.floor(hours / 24);

        if (days > 0) return `${days}d ${hours % 24}h`;
        if (hours > 0) return `${hours}h ${minutes % 60}m`;
        if (minutes > 0) return `${minutes}m ${seconds % 60}s`;
        return `${seconds}s`;
    }

    formatSize(bytes) {
        const units = ['B', 'KB', 'MB', 'GB', 'TB'];
        let size = bytes;
        let unitIndex = 0;
        while (size >= 1024 && unitIndex < units.length - 1) {
            size /= 1024;
            unitIndex++;
        }
        return `${size.toFixed(2)} ${units[unitIndex]}`;
    }

    formatTimestamp(timestamp) {
        const date = new Date(timestamp);
        return date.toLocaleString('id-ID', {
            day: '2-digit',
            month: '2-digit',
            year: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit'
        });
    }
}

module.exports = new Logger();