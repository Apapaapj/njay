// ================================================================
// CLIENT MODEL
// Data structure for connected clients
// ================================================================

class ClientModel {
    constructor(data = {}) {
        this.id = data.id || this.generateId();
        this.name = data.name || 'Unknown Device';
        this.os = data.os || 'Android';
        this.ip = data.ip || '0.0.0.0';
        this.battery = data.battery || 'N/A';
        this.status = data.status || 'offline';
        this.ws = data.ws || null;
        this.lastSeen = data.lastSeen || new Date().toISOString();
        this.connectedAt = data.connectedAt || new Date().toISOString();
        this.commandsExecuted = data.commandsExecuted || 0;
        this.lastCommand = data.lastCommand || null;
    }

    generateId() {
        return 'xxxxxxxxxxxx'.replace(/x/g, () => {
            return Math.random().toString(36).substring(2, 3);
        });
    }

    toJSON() {
        return {
            id: this.id,
            name: this.name,
            os: this.os,
            ip: this.ip,
            battery: this.battery,
            status: this.status,
            lastSeen: this.lastSeen,
            connectedAt: this.connectedAt,
            commandsExecuted: this.commandsExecuted,
            lastCommand: this.lastCommand
        };
    }

    toPublicJSON() {
        return {
            id: this.id,
            name: this.name,
            os: this.os,
            ip: this.ip,
            battery: this.battery,
            status: this.status,
            lastSeen: this.lastSeen
        };
    }

    update(data) {
        if (data.name) this.name = data.name;
        if (data.os) this.os = data.os;
        if (data.ip) this.ip = data.ip;
        if (data.battery) this.battery = data.battery;
        if (data.status) this.status = data.status;
        if (data.lastSeen) this.lastSeen = data.lastSeen;
        this.lastSeen = new Date().toISOString();
        return this;
    }

    setOnline() {
        this.status = 'online';
        this.lastSeen = new Date().toISOString();
        return this;
    }

    setOffline() {
        this.status = 'offline';
        this.lastSeen = new Date().toISOString();
        return this;
    }

    recordCommand(command) {
        this.commandsExecuted++;
        this.lastCommand = {
            command: command,
            timestamp: new Date().toISOString()
        };
        return this;
    }

    isOnline() {
        return this.status === 'online' && this.ws !== null;
    }

    isExpired(timeout = 60000) {
        const lastSeenMs = new Date(this.lastSeen).getTime();
        const nowMs = Date.now();
        return (nowMs - lastSeenMs) > timeout;
    }
}

module.exports = ClientModel;