// ================================================================
// CLIENT CONTROLLER
// Manage connected clients
// ================================================================

const ClientModel = require('../models/clientModel');
const fs = require('fs');
const path = require('path');

const CLIENTS_FILE = path.join(__dirname, '../../clients.json');

class ClientController {
    constructor() {
        this.clients = new Map(); // id -> ClientModel
        this.loadFromFile();
    }

    // ============================================================
    // CRUD OPERATIONS
    // ============================================================

    create(data) {
        const client = new ClientModel(data);
        this.clients.set(client.id, client);
        this.saveToFile();
        return client;
    }

    get(id) {
        return this.clients.get(id) || null;
    }

    getAll() {
        return Array.from(this.clients.values());
    }

    getOnline() {
        return this.getAll().filter(c => c.isOnline());
    }

    getOffline() {
        return this.getAll().filter(c => !c.isOnline());
    }

    update(id, data) {
        const client = this.get(id);
        if (!client) return null;
        client.update(data);
        this.saveToFile();
        return client;
    }

    delete(id) {
        const deleted = this.clients.delete(id);
        if (deleted) this.saveToFile();
        return deleted;
    }

    // ============================================================
    // WEBSOCKET MANAGEMENT
    // ============================================================

    setWebSocket(id, ws) {
        const client = this.get(id);
        if (!client) return null;
        client.ws = ws;
        client.setOnline();
        this.saveToFile();
        return client;
    }

    removeWebSocket(id) {
        const client = this.get(id);
        if (!client) return null;
        client.ws = null;
        client.setOffline();
        this.saveToFile();
        return client;
    }

    // ============================================================
    // COMMAND RECORDING
    // ============================================================

    recordCommand(id, command) {
        const client = this.get(id);
        if (!client) return null;
        client.recordCommand(command);
        this.saveToFile();
        return client;
    }

    // ============================================================
    // PERSISTENCE
    // ============================================================

    loadFromFile() {
        try {
            if (fs.existsSync(CLIENTS_FILE)) {
                const data = fs.readFileSync(CLIENTS_FILE, 'utf8');
                const parsed = JSON.parse(data);
                Object.keys(parsed).forEach(id => {
                    const client = new ClientModel(parsed[id]);
                    client.status = 'offline';
                    client.ws = null;
                    this.clients.set(id, client);
                });
                console.log(`[LOAD] ${this.clients.size} clients loaded`);
            }
        } catch (err) {
            console.log('[LOAD] No saved clients found');
        }
    }

    saveToFile() {
        try {
            const data = {};
            this.clients.forEach((client, id) => {
                data[id] = client.toJSON();
                // Don't save websocket object
                delete data[id].ws;
            });
            fs.writeFileSync(CLIENTS_FILE, JSON.stringify(data, null, 2));
        } catch (err) {
            console.log('[SAVE] Error saving clients:', err.message);
        }
    }

    // ============================================================
    // UTILITY
    // ============================================================

    getStats() {
        const all = this.getAll();
        const online = this.getOnline();
        const offline = this.getOffline();
        return {
            total: all.length,
            online: online.length,
            offline: offline.length,
            lastUpdated: new Date().toISOString()
        };
    }

    cleanup(timeout = 60000) {
        let cleaned = 0;
        this.clients.forEach((client, id) => {
            if (client.isExpired(timeout) && !client.isOnline()) {
                this.clients.delete(id);
                cleaned++;
            }
        });
        if (cleaned > 0) {
            this.saveToFile();
            console.log(`[CLEANUP] Removed ${cleaned} expired clients`);
        }
        return cleaned;
    }

    toPublicJSON() {
        return this.getAll().map(c => c.toPublicJSON());
    }
}

module.exports = new ClientController();